var searchData=
[
  ['quit',['quit',['../class_main_window.html#a542a7527ced73b2c9bc14f8dc9661a66',1,'MainWindow']]],
  ['quitbutton',['quitButton',['../class_main_window.html#aa54dd1591420ab62926bf63ea68f85f8',1,'MainWindow']]],
  ['quitlabel',['quitLabel',['../class_main_window.html#abdacefc65d91f1c0da191fe12f7335b5',1,'MainWindow']]],
  ['quitrejected',['quitRejected',['../class_main_window.html#a044e57ff6270263997003d8926809a05',1,'MainWindow']]]
];
