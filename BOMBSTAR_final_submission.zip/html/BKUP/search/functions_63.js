var searchData=
[
  ['changecolorscheme',['changeColorScheme',['../class_main_window.html#a71a95d0e760c02a5967e3bd7f93ac659',1,'MainWindow']]],
  ['checkspecials',['checkSpecials',['../class_main_window.html#a70ebaea425e3e9ae419e7c743044f538',1,'MainWindow']]],
  ['colors',['Colors',['../class_colors.html#ada43d33ada10bf84f352fbd2411050ba',1,'Colors']]],
  ['confirmquit',['confirmQuit',['../class_main_window.html#aff7ce974fd1010fe57be7d11eee74525',1,'MainWindow']]]
];
