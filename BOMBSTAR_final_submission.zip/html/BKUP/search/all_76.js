var searchData=
[
  ['verticalflip',['verticalFlip',['../class_main_window.html#a50ced8b18740ce902530504d8a96840a',1,'MainWindow']]]
];
