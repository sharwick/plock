var searchData=
[
  ['colors',['Colors',['../class_colors.html',1,'']]]
];
