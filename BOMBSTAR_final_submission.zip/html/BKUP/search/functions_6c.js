var searchData=
[
  ['leftcollector',['leftCollector',['../class_block.html#a0071dc67fffb5790af4cf95156a451fb',1,'Block']]],
  ['loadhighscores',['loadHighScores',['../class_high_scores.html#a02be252e02f744aeb30c66e75704c002',1,'HighScores']]]
];
