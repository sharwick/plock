var searchData=
[
  ['downblockptr',['downBlockPtr',['../class_block.html#a3ecbd8ebd47fe0ba77e4b2a7e989d546',1,'Block']]]
];
