var searchData=
[
  ['quit',['quit',['../class_main_window.html#a542a7527ced73b2c9bc14f8dc9661a66',1,'MainWindow']]],
  ['quitrejected',['quitRejected',['../class_main_window.html#a044e57ff6270263997003d8926809a05',1,'MainWindow']]],
  ['quitrejectedgameover',['quitRejectedGameOver',['../class_main_window.html#a7b18fe90f1a5411909130844b757e0ad',1,'MainWindow']]]
];
