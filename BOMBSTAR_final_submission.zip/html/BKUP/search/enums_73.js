var searchData=
[
  ['screenorientation',['ScreenOrientation',['../class_main_window.html#abd5f153be5c4988dbc35ae7c1f25d903',1,'MainWindow']]]
];
