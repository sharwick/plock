var searchData=
[
  ['finallevellabel',['finalLevelLabel',['../class_main_window.html#a2ad6cafb8f12fc43432bcaf8d3d1d619',1,'MainWindow']]],
  ['finalscorelabel',['finalScoreLabel',['../class_main_window.html#afd24c2bccc2d79a4691c75e760fff7c1',1,'MainWindow']]]
];
