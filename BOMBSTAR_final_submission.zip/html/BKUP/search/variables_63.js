var searchData=
[
  ['color',['color',['../class_block.html#a11fa34418f20b6613d0ceeea8fc71d25',1,'Block']]],
  ['colorarray',['colorArray',['../class_colors.html#a91992a2870b8e80bd554520d2552a229',1,'Colors']]],
  ['coloredbool',['coloredBool',['../class_block.html#af2a045558af6ef0ca1af70a19f107ac9',1,'Block']]],
  ['colorptr',['colorPtr',['../class_main_window.html#acb0cbd1417e59f5cbe69ed01d5f78af7',1,'MainWindow']]],
  ['colorscheme',['colorScheme',['../class_colors.html#ac71c955d4cf549e066756519fc886246',1,'Colors']]],
  ['colorschemelabel',['colorSchemeLabel',['../class_main_window.html#a58de97f4ab1cdedbae84df27c2322d9d',1,'MainWindow']]],
  ['colorslider',['colorSlider',['../class_main_window.html#a9a3ac59690bb71ef2adf9d44ba74c276',1,'MainWindow']]],
  ['confirmacceptbutton',['confirmAcceptButton',['../class_main_window.html#a1eda92b8f13e9b104cb04eb3a4dc25aa',1,'MainWindow']]],
  ['confirmlayout',['confirmLayout',['../class_main_window.html#a754eb90c18277ec5dd672b82a15ebc04',1,'MainWindow']]],
  ['confirmmenu',['confirmMenu',['../class_main_window.html#aefdfdd6e7b2e1c30b03601e630f56160',1,'MainWindow']]],
  ['confirmrejectbutton',['confirmRejectButton',['../class_main_window.html#aef3e9d3f426317df533dd769714759ea',1,'MainWindow']]],
  ['coordx',['CoordX',['../class_block.html#a9ff4a19bbf4dce76b262c92bfeb8877f',1,'Block']]],
  ['coordy',['CoordY',['../class_block.html#aff80267f164e5f0d2230001a7673ef56',1,'Block']]],
  ['currenttime',['currentTime',['../class_main_window.html#a5673d58b28cd83a69b0e1053e9653081',1,'MainWindow']]]
];
