var searchData=
[
  ['newgamepressed',['newGamePressed',['../class_main_window.html#a28c17baf810a843ce1231f77993e4b39',1,'MainWindow']]],
  ['nextlevel',['nextLevel',['../class_main_window.html#adbca3a021f004547a7a21b1d0b6629be',1,'MainWindow']]]
];
