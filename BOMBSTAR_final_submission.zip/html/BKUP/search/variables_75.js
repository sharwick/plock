var searchData=
[
  ['ui',['ui',['../class_main_window.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow']]],
  ['upblockptr',['upBlockPtr',['../class_block.html#a8adcfaa2e32fea649f1948ee19489441',1,'Block']]]
];
