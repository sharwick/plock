var searchData=
[
  ['endlessmode',['endlessMode',['../class_main_window.html#a82ac4a5e898064a14f568ac1c299bc74',1,'MainWindow']]]
];
