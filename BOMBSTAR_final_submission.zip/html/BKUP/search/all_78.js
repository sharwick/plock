var searchData=
[
  ['x',['x',['../class_main_window.html#ab047df0257e3fa5d8710f1df552924fe',1,'MainWindow']]],
  ['xpos',['xPos',['../class_main_window.html#aaadeabcaaee1d42ab65190ef43e5eea3',1,'MainWindow']]]
];
