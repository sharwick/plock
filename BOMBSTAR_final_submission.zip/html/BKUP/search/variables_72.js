var searchData=
[
  ['rightblockptr',['rightBlockPtr',['../class_block.html#a41c0bd014db6c23abcf0459baa1ec410',1,'Block']]],
  ['rotatebutton',['rotateButton',['../class_main_window.html#ac2cec1e150d2a6d0a5ffea755d9caf69',1,'MainWindow']]]
];
