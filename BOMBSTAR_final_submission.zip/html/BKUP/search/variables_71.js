var searchData=
[
  ['quitbutton',['quitButton',['../class_main_window.html#aa54dd1591420ab62926bf63ea68f85f8',1,'MainWindow']]],
  ['quitlabel',['quitLabel',['../class_main_window.html#abdacefc65d91f1c0da191fe12f7335b5',1,'MainWindow']]]
];
