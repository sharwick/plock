var searchData=
[
  ['n',['n',['../class_main_window.html#ade2df6e0e2fa5a3b19b7e0bce2c9dc0f',1,'MainWindow']]],
  ['newgamebutton',['newGameButton',['../class_main_window.html#afde5b352348fc655dc5dd47e2e074288',1,'MainWindow']]],
  ['newhighscore',['newHighScore',['../class_main_window.html#a7dfb53796b2a5ea6dc045de0357748bd',1,'MainWindow']]]
];
