var searchData=
[
  ['n',['n',['../class_main_window.html#ade2df6e0e2fa5a3b19b7e0bce2c9dc0f',1,'MainWindow']]],
  ['newgamebutton',['newGameButton',['../class_main_window.html#afde5b352348fc655dc5dd47e2e074288',1,'MainWindow']]],
  ['newgamepressed',['newGamePressed',['../class_main_window.html#a28c17baf810a843ce1231f77993e4b39',1,'MainWindow']]],
  ['newhighscore',['newHighScore',['../class_main_window.html#a7dfb53796b2a5ea6dc045de0357748bd',1,'MainWindow']]],
  ['nextlevel',['nextLevel',['../class_main_window.html#adbca3a021f004547a7a21b1d0b6629be',1,'MainWindow']]]
];
