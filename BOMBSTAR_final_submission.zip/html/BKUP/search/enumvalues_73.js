var searchData=
[
  ['screenorientationauto',['ScreenOrientationAuto',['../class_main_window.html#abd5f153be5c4988dbc35ae7c1f25d903ac6b5fe3ca97c62b5c9c5c55edb09027d',1,'MainWindow']]],
  ['screenorientationlocklandscape',['ScreenOrientationLockLandscape',['../class_main_window.html#abd5f153be5c4988dbc35ae7c1f25d903ad17797d910e72ac4ae7fd7c88ee43224',1,'MainWindow']]],
  ['screenorientationlockportrait',['ScreenOrientationLockPortrait',['../class_main_window.html#abd5f153be5c4988dbc35ae7c1f25d903a13a4781d324c19835f8673230efc7b3d',1,'MainWindow']]]
];
