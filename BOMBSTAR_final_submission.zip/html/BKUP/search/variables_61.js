var searchData=
[
  ['aboutlabel',['aboutLabel',['../class_main_window.html#a87a3f4081d8ba14e2ce15b0ee17354dc',1,'MainWindow']]],
  ['abouttext',['aboutText',['../class_main_window.html#a2bfe9832b2a8d8d1d5a08484d82da0b5',1,'MainWindow']]]
];
