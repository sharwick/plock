var searchData=
[
  ['determinecolor',['determineColor',['../class_main_window.html#a62ff3f1dff8ca82774c40b6999bd1258',1,'MainWindow']]],
  ['downcollector',['downCollector',['../class_block.html#a63b9cf215b8ea29cb12008605d9e7580',1,'Block']]]
];
